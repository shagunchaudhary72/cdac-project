package com.app.services;

public interface IStudentService {
	

}
